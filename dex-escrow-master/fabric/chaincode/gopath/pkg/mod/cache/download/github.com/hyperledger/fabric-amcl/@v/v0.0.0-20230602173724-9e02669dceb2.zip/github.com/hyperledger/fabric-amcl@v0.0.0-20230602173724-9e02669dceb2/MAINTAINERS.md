[//]: # (SPDX-License-Identifier: Apache-2.0)

# Maintainers

Please refer to the [Hyperledger Fabric](https://github.com/hyperledger/fabric/blob/main/MAINTAINERS.md)
maintainer list.
