---
name: Feature request
about: Suggest an idea for this project
title: ""
labels: ""
assignees: ""
---

#### Description

<!-- A clear and concise description of what the missing capability is, why it's a problem and what you want to happen -->

#### Additional context

<!-- Add any other context or links to existing implementations of the feature in other Kafka clients -->
<!-- Please link to the relevant KIP from https://cwiki.apache.org/confluence/display/KAFKA/Kafka+Improvement+Proposals if appropriate -->
